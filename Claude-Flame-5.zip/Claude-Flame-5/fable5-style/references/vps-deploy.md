# Деплой на VPS — systemd + venv + PostgreSQL

## Установка проекта

```bash
sudo apt update && sudo apt install -y python3-venv git
sudo mkdir -p /opt && cd /opt
sudo git clone <repo_url> mybot && cd mybot
sudo python3 -m venv venv
sudo venv/bin/pip install -r requirements.txt
```

## Секреты: .env + EnvironmentFile

`/opt/mybot/.env` (права `chmod 600`):

```
BOT_TOKEN=123456:ABC...
DATABASE_URL=postgresql+asyncpg://bot:PASSWORD@localhost/botdb
```

В коде: `os.getenv("BOT_TOKEN")`. Токен в git не попадает (`.env` в `.gitignore`).

## systemd unit

`/etc/systemd/system/mybot.service`:

```ini
[Unit]
Description=Telegram bot
After=network.target postgresql.service

[Service]
User=botuser
WorkingDirectory=/opt/mybot
EnvironmentFile=/opt/mybot/.env
ExecStart=/opt/mybot/venv/bin/python main.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now mybot
journalctl -u mybot -f        # живые логи
```

## PostgreSQL

```bash
sudo apt install -y postgresql
sudo -u postgres psql -c "CREATE USER bot WITH PASSWORD 'PASSWORD';"
sudo -u postgres psql -c "CREATE DATABASE botdb OWNER bot;"
```

## Обновление версии

```bash
cd /opt/mybot && sudo git pull
sudo venv/bin/pip install -r requirements.txt
sudo systemctl restart mybot && journalctl -u mybot -n 30
```

## Polling vs webhook

- Long polling: не нужен домен и HTTPS — дефолт для ботов.
- Webhook нужен для высокой нагрузки или когда уже есть бэкенд Mini App: nginx + certbot (Let's Encrypt), локация проксирует на FastAPI/aiohttp.
