# Telegram Mini App — проверенные паттерны

## Валидация initData на бэкенде (FastAPI) — обязательна

Ни один запрос с фронта не обслуживается без проверки подписи. `user_id` берётся ТОЛЬКО из проверенного initData, никогда из тела запроса.

```python
import hashlib
import hmac
import json
import os
from urllib.parse import parse_qsl

from fastapi import FastAPI, Header, HTTPException

BOT_TOKEN = os.getenv("BOT_TOKEN")

def validate_init_data(init_data: str) -> dict:
    try:
        parsed = dict(parse_qsl(init_data, keep_blank_values=True))
        received_hash = parsed.pop("hash")
    except (ValueError, KeyError):
        raise HTTPException(401, "bad initData")
    check_string = "\n".join(f"{k}={v}" for k, v in sorted(parsed.items()))
    secret = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
    calc = hmac.new(secret, check_string.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calc, received_hash):
        raise HTTPException(401, "invalid hash")
    return json.loads(parsed["user"])  # {"id": ..., "first_name": ..., "username": ...}

app = FastAPI()

@app.get("/api/me")
async def me(authorization: str = Header(...)):
    user = validate_init_data(authorization.removeprefix("tma "))
    return {"id": user["id"], "name": user.get("first_name")}
```

## Фронтенд — минимум для запуска

```html
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<script>
  const tg = window.Telegram.WebApp;
  tg.ready();
  tg.expand();

  fetch("/api/me", {
    headers: { Authorization: "tma " + tg.initData },
  }).then(r => r.json()).then(console.log);

  tg.MainButton.setText("Сохранить");
  tg.MainButton.show();
  tg.MainButton.onClick(() => { /* submit */ });
</script>
```

## Ключевые факты

- Запуск: inline-кнопка `InlineKeyboardButton(text=..., web_app=WebAppInfo(url=...))` или Menu Button через BotFather.
- URL только HTTPS. Локальная разработка — туннель (cloudflared / ngrok).
- Тема: CSS-переменные `var(--tg-theme-bg-color)`, `var(--tg-theme-text-color)` и т.д. — приложение обязано выглядеть нормально в тёмной теме.
- `tg.sendData(...)` (без бэкенда) работает только из кнопки reply-клавиатуры; данные приходят боту как `message.web_app_data.data`.
- Аудиофайлы/тяжёлый контент раздавать со своего бэкенда или CDN, не через Bot API на лету.
