# Google Apps Script — проверенные паттерны

## Главное правило: батчи, а не поячеечное чтение

```javascript
function processSheet() {
  const sheet = SpreadsheetApp.getActive().getSheetByName('Данные');
  if (!sheet) throw new Error('Лист "Данные" не найден');
  const values = sheet.getDataRange().getValues();   // ОДНО чтение
  const out = values.slice(1).map(row => [row[0], Number(row[1]) * 2]);
  sheet.getRange(2, 5, out.length, 2).setValues(out); // ОДНА запись
}
```

`getValue()`/`setValue()` в цикле — отдельный API-вызов на каждую ячейку; скрипт упирается в таймаут 6 минут.

## Отправка отчёта в Telegram

```javascript
function sendTelegram(text) {
  const props = PropertiesService.getScriptProperties();
  const token = props.getProperty('BOT_TOKEN');
  const chatId = props.getProperty('CHAT_ID');
  const resp = UrlFetchApp.fetch('https://api.telegram.org/bot' + token + '/sendMessage', {
    method: 'post',
    contentType: 'application/json',
    payload: JSON.stringify({ chat_id: chatId, text: text, parse_mode: 'HTML' }),
    muteHttpExceptions: true,
  });
  if (resp.getResponseCode() !== 200) {
    console.error('Telegram error: ' + resp.getContentText());
  }
}
```

- Токены и chat_id — только в Script Properties, не в коде.
- Лимит сообщения 4096 символов — длинные отчёты резать на части.

## Устойчивость к изменениям таблицы

- Не привязываться к буквам колонок. Колонку искать по ключевому слову в строке заголовков (нормализовать: `String(h).toLowerCase().trim()`, сравнивать через `includes`/prefix).
- Проверять, что лист и колонки найдены; если нет — понятная ошибка в лог, а не тихий мусор в отчёте.
- Держать диагностическую функцию (например, `testRecognizeColumns()`), которая печатает, какая колонка на что распозналась.

## Триггеры и лимиты

- Клок-триггеры: интерфейс «Триггеры» или `ScriptApp.newTrigger('main').timeBased().everyHours(1).create()`.
- Лимиты (обычный аккаунт): выполнение до 6 мин; UrlFetch ~20 000/сутки; суммарное время триггеров 90 мин/сутки.
- Логи выполнения по триггеру — в разделе «Выполнения» редактора.
