# aiogram 3 + SQLAlchemy 2 async — проверенные паттерны

Читать перед любым кодом Telegram-бота.

## Каркас бота (main.py)

```python
import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

from config import BOT_TOKEN
from handlers import user, admin

async def main():
    logging.basicConfig(level=logging.INFO)
    bot = Bot(BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher(storage=MemoryStorage())
    dp.include_routers(user.router, admin.router)
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
```

## Хендлеры — только Router

```python
from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.types import CallbackQuery, Message

router = Router()

@router.message(CommandStart())
async def cmd_start(message: Message):
    await message.answer("Привет!")

@router.callback_query(F.data == "menu")
async def cb_menu(callback: CallbackQuery):
    await callback.message.edit_text("Меню")
    await callback.answer()  # обязательно, иначе у пользователя висят «часики»
```

## FSM

```python
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

class Reg(StatesGroup):
    name = State()
    position = State()

@router.message(Command("reg"))
async def reg_start(message: Message, state: FSMContext):
    await state.set_state(Reg.name)
    await message.answer("Как тебя зовут?")

@router.message(Reg.name, F.text)
async def reg_name(message: Message, state: FSMContext):
    await state.update_data(name=message.text.strip())
    await state.set_state(Reg.position)
    await message.answer("Позиция на поле?")

# завершение: data = await state.get_data(); ...; await state.clear()
```

## CallbackData-фабрика вместо ручного парсинга строк

```python
from aiogram.filters.callback_data import CallbackData
from aiogram.utils.keyboard import InlineKeyboardBuilder

class MatchCb(CallbackData, prefix="match"):
    action: str
    match_id: int

kb = InlineKeyboardBuilder()
kb.button(text="Голосовать", callback_data=MatchCb(action="vote", match_id=42))
kb.adjust(1)
await message.answer("Матч #42", reply_markup=kb.as_markup())

@router.callback_query(MatchCb.filter(F.action == "vote"))
async def vote(callback: CallbackQuery, callback_data: MatchCb):
    match_id = callback_data.match_id
    ...
    await callback.answer("Голос учтён")
```

## Типовые ошибки (не тащить привычки из aiogram 2)

- `executor` не существует → `await dp.start_polling(bot)`.
- `@dp.message_handler(...)` → `@router.message(...)`.
- Фильтры текста — магические: `F.text == "..."`, `F.data.startswith("...")`.
- `ReplyKeyboardMarkup`/`InlineKeyboardMarkup` — только именованные аргументы (`keyboard=[[...]]`, `resize_keyboard=True`).
- `parse_mode` задаётся через `DefaultBotProperties` (aiogram ≥ 3.7), не аргументом `Bot(...)`.
- Забытый `await callback.answer()` — самый частый баг с inline-кнопками.
- Анти-дабл-клик: после обработки нажатия сразу `edit_reply_markup(reply_markup=None)` или проверка состояния в БД.

## SQLAlchemy 2.0 async

```python
# db.py
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

class Base(DeclarativeBase):
    pass

engine = create_async_engine("sqlite+aiosqlite:///bot.db")
# прод: create_async_engine(os.getenv("DATABASE_URL"))  # postgresql+asyncpg://...
Session = async_sessionmaker(engine, expire_on_commit=False)
```

```python
# models.py
from sqlalchemy import BigInteger
from sqlalchemy.orm import Mapped, mapped_column
from db import Base

class Player(Base):
    __tablename__ = "players"
    id: Mapped[int] = mapped_column(primary_key=True)
    tg_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    name: Mapped[str]
```

```python
# использование
from sqlalchemy import select
from db import Session

async with Session() as session:
    player = await session.scalar(select(Player).where(Player.tg_id == tg_id))
    if player is None:
        session.add(Player(tg_id=tg_id, name=name))
        await session.commit()
```

- `tg_id` всегда `BigInteger` — Telegram ID не влезают в обычный `Integer`.
- `expire_on_commit=False`, иначе объекты «протухают» после `commit()`.
- Запросы в стиле 2.0: `select(...)` + `session.scalar/scalars`, не `session.query`.
